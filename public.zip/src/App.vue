<template>
  <router-view></router-view>
</template>

<script>

export default {
  components: {

  }
}
</script>

<style>
body{
  margin: 0
}
</style>
